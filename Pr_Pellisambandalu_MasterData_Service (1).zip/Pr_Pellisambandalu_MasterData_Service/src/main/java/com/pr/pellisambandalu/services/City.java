package com.pr.pellisambandalu.services;

public interface City {

}

package com.pr.pellisambandalu.models;

public class Caste {

}

package com.pr.pellisambandalu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrPellisambandaluMasterDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrPellisambandaluMasterDataServiceApplication.class, args);
	}

}

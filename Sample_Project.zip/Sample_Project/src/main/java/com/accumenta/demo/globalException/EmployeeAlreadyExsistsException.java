package com.accumenta.demo.globalException;

public class EmployeeAlreadyExsistsException extends RuntimeException
{

	public EmployeeAlreadyExsistsException(String message) {
		// TODO Auto-generated constructor stub
	}
		
}

package com.accumenta.demo.globalException;

import com.accumenta.demo.entity.Company;

public class CompanyAlreadyExistsException extends RuntimeException 
{

	public CompanyAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}

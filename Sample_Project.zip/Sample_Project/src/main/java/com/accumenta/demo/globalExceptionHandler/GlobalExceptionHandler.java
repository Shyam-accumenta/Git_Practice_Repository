package com.accumenta.demo.globalExceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.accumenta.demo.dto.ResponseWrapper;
import com.accumenta.demo.globalException.CompanyAlreadyExistsException;
import com.accumenta.demo.globalException.EmployeeAlreadyExsistsException;

@ControllerAdvice
public class GlobalExceptionHandler 
{

	@ExceptionHandler(CompanyAlreadyExistsException.class)
	ResponseEntity<ResponseWrapper> ComapanyAltreadyExists(CompanyAlreadyExistsException ex)
	{
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseWrapper(ex));
	}
	
	@ExceptionHandler(EmployeeAlreadyExsistsException.class)
	ResponseEntity<ResponseWrapper> EmployeeAltreadyExists(EmployeeAlreadyExsistsException ex)
	{
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseWrapper(ex));
	}
	
	

}

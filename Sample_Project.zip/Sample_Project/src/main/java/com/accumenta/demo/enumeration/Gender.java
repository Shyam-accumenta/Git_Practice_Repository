package com.accumenta.demo.enumeration;

public enum Gender 
{
	Male,Female,other

}

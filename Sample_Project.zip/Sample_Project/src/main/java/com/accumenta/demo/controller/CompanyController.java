package com.accumenta.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.accumenta.demo.dto.ResponseWrapper;
import com.accumenta.demo.entity.Company;
import com.accumenta.demo.entity.Employee;
import com.accumenta.demo.service.CompanyService;
import com.accumenta.demo.service.EmployeeService;


@RestController
public class CompanyController 
{
	@Autowired
	private CompanyService service;
	 
	@Autowired
	private EmployeeService empService;
	
	@PostMapping("/api/company")
	public ResponseEntity<ResponseWrapper> createCompany(@RequestBody Company company )
	{
		Company dbCompany=this.service.addCompany(company);
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper(dbCompany));
	}
	@PostMapping("/api/employee")
	public ResponseEntity<ResponseWrapper> createEmployee(@RequestParam long companyId,@RequestBody Employee employee)
	{
		Employee dbEmployee=this.empService.addemployee(companyId,employee);
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper(dbEmployee));
	}
}


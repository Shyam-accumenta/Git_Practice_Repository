package com.accumenta.demo.serviceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accumenta.demo.entity.Company;
import com.accumenta.demo.globalException.CompanyAlreadyExistsException;
import com.accumenta.demo.repository.CompanyRepository;
import com.accumenta.demo.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService
{
	@Autowired
	private CompanyRepository comRepo;

	@Override
	public Company addCompany(Company company) 
	{
		Company comp=this.comRepo.findById(company.getComId()).orElse(null);
		if (comp==null) 
		{
			
			return this.comRepo.save(company);
			
		}
		else
		{
			throw new CompanyAlreadyExistsException("Company Already Exist");
		}
	}
}

package com.accumenta.demo.entity;

import com.accumenta.demo.enumeration.Gender;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Employee 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long empid;
	
	
	private String empName;
	
	
	private String empDesignation;
	
	
	private String empLoc;
	
	@Enumerated(EnumType.STRING)
	private Gender gender;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "comapny_id")
	private Company company; 
}

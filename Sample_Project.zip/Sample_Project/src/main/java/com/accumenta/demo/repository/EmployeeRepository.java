package com.accumenta.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accumenta.demo.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>
{

}

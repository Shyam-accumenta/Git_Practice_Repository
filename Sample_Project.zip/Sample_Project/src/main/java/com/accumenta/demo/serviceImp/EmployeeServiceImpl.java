package com.accumenta.demo.serviceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accumenta.demo.entity.Company;
import com.accumenta.demo.entity.Employee;
import com.accumenta.demo.globalException.EmployeeAlreadyExsistsException;
import com.accumenta.demo.repository.CompanyRepository;
import com.accumenta.demo.repository.EmployeeRepository;
import com.accumenta.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService
{
	@Autowired
	private EmployeeRepository repo;
	
	@Autowired
	private CompanyRepository companyRepository;

	@Override
	public Employee addemployee(long companyId,Employee emp) 
	{
		Employee employe=this.repo.findById(emp.getEmpid()).orElse(null);
		Company dbCompany = this.companyRepository.findById(companyId).get();
		if (employe==null) 
		{
			emp.setCompany(dbCompany);
			return repo.save(emp);
		}
		else
		{
			throw new EmployeeAlreadyExsistsException("Employee Already Exist");
		}	
	}

}

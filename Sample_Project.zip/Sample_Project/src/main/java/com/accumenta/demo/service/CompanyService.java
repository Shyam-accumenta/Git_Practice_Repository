package com.accumenta.demo.service;

import com.accumenta.demo.entity.Company;

public interface CompanyService 
{
	Company addCompany(Company company);
}

package com.accumenta.demo.service;

import com.accumenta.demo.entity.Employee;

public interface EmployeeService 
{
	Employee addemployee(long companyId,Employee emp);

}

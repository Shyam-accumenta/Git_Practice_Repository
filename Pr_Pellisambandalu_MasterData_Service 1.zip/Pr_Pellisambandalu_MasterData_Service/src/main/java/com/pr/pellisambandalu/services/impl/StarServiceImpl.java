package com.pr.pellisambandalu.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pr.pellisambandalu.models.Star;
import com.pr.pellisambandalu.services.StarService;

@Service
public class StarServiceImpl implements StarService{

	@Override
	public String addStart(Star star) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Star> getStars() {
		// TODO Auto-generated method stub
		return null;
	}


}

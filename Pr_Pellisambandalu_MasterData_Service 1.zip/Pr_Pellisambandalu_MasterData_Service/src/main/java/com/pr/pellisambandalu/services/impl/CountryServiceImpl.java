package com.pr.pellisambandalu.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pr.pellisambandalu.models.Country;
import com.pr.pellisambandalu.services.CountryService;

@Service
public class CountryServiceImpl implements CountryService{

	@Override
	public String addCountry(Country country) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Country> getCountries() {
		// TODO Auto-generated method stub
		return null;
	}

}

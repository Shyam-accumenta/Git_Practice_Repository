package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.ZodiacSign;

public interface ZodiacSignService {
	
	String addZodiacSignService(ZodiacSign zodiacSign);
	List<ZodiacSign> zodiacSigns();

}

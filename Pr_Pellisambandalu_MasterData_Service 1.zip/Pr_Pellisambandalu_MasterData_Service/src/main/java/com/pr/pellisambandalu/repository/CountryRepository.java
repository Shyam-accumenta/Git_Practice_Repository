package com.pr.pellisambandalu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pr.pellisambandalu.models.Country;

public interface CountryRepository extends JpaRepository<Country, Long> {

}

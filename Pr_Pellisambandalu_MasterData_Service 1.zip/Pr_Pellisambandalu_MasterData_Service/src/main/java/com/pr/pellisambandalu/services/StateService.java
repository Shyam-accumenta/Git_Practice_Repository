package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.State;

public interface StateService {
	
	String addState(String countryName,State state);
	List<State> getStates();

}

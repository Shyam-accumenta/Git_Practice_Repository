package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.Religion;

public interface ReligionService {

	String addReligionService(Religion religion);

	List<Religion> getReligions();

}

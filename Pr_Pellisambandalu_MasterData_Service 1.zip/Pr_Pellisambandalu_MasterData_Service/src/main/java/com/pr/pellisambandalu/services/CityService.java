package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.City;

public interface CityService {
	
	String addCity(String stateName,City city);
	List<City> getCities();

}

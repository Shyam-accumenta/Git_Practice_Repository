package com.pr.pellisambandalu.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pr.pellisambandalu.models.Caste;
import com.pr.pellisambandalu.services.CasteService;

@Service
public class CasteServiceImpl implements CasteService{

	@Override
	public String addCaste(Caste caste) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Caste> allCastes() {
		// TODO Auto-generated method stub
		return null;
	}

	

}

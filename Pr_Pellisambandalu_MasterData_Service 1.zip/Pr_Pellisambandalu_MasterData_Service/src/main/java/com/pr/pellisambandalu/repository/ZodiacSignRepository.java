package com.pr.pellisambandalu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pr.pellisambandalu.models.ZodiacSign;

public interface ZodiacSignRepository extends JpaRepository<ZodiacSign, Long> {

}

package com.pr.pellisambandalu.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pr.pellisambandalu.models.Religion;
import com.pr.pellisambandalu.services.ReligionService;

@Service
public class ReligionServiceImpl implements ReligionService{

	@Override
	public String addReligionService(Religion religion) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Religion> getReligions() {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.NameOfInstitute;

public interface NameOfInstituteService {

	String addNameOfInstitute(NameOfInstitute nameOfInstitute);

	String deleteNameOfInstitute(NameOfInstitute nameOfInstitute);

	NameOfInstitute getNameOfInstitute(NameOfInstitute nameOfInstitute);

	List<NameOfInstitute> getNameOfInstitutes();

}

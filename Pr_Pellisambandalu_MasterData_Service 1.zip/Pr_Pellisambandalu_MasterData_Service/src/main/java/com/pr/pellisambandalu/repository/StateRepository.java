package com.pr.pellisambandalu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pr.pellisambandalu.models.State;

public interface StateRepository extends JpaRepository<State, Long> {

}

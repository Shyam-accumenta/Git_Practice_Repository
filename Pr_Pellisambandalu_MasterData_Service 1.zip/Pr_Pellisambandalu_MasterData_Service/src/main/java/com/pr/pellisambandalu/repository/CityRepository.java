package com.pr.pellisambandalu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pr.pellisambandalu.models.City;

public interface CityRepository extends JpaRepository<City, Long> {

}

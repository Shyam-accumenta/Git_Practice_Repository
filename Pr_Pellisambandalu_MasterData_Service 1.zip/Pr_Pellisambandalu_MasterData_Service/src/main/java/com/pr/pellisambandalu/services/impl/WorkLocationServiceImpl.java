package com.pr.pellisambandalu.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pr.pellisambandalu.models.WorkLocation;
import com.pr.pellisambandalu.services.WorkLocationService;

@Service
public class WorkLocationServiceImpl implements WorkLocationService {

	@Override
	public String addWorkLocation(WorkLocation workLocation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkLocation> getWorkLocations() {
		// TODO Auto-generated method stub
		return null;
	}

}

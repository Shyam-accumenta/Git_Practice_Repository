package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.SubCaste;

public interface SubCasteService {

	String addSubCaste(String casteName,SubCaste subCaste);

	List<SubCaste> getSubCaste();

}

package com.pr.pellisambandalu.services.impl;

import java.util.List;

import com.pr.pellisambandalu.models.State;
import com.pr.pellisambandalu.services.StateService;

public class StateServiceImpl implements StateService{


	@Override
	public List<State> getStates() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addState(String countryName, State state) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.pr.pellisambandalu.services.impl;

import java.util.List;

import com.pr.pellisambandalu.models.SubCaste;
import com.pr.pellisambandalu.services.SubCasteService;

public class SubCasteServiceImpl implements SubCasteService{
	
	@Override
	public List<SubCaste> getSubCaste() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addSubCaste(String casteName, SubCaste subCaste) {
		// TODO Auto-generated method stub
		return null;
	}

}

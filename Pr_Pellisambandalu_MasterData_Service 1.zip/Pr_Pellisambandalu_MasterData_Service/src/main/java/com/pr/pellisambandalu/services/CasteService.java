package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.Caste;

public interface CasteService {

	String addCaste(Caste caste);

	List<Caste> allCastes();

}

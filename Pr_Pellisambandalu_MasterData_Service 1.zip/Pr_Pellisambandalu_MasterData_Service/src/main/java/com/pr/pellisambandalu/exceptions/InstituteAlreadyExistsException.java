package com.pr.pellisambandalu.exceptions;

public class InstituteAlreadyExistsException extends RuntimeException {

	public InstituteAlreadyExistsException() {
		// TODO Auto-generated constructor stub
	}

	public InstituteAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InstituteAlreadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InstituteAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InstituteAlreadyExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

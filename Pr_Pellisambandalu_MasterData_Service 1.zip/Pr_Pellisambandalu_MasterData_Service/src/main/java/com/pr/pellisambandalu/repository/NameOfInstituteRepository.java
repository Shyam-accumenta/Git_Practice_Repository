package com.pr.pellisambandalu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.RequestParam;

import com.pr.pellisambandalu.models.NameOfInstitute;

public interface NameOfInstituteRepository extends JpaRepository<NameOfInstitute, Integer>{
	
	@Query("select n from NameOfInstitute n where n.instituteName=:instituteName")
//	@Query(value="select * from name_of_institute where n.institute_name := instituteName",nativeQuery = true) //Native Query
	NameOfInstitute findByName(@RequestParam("instituteName") String instituteName);

}

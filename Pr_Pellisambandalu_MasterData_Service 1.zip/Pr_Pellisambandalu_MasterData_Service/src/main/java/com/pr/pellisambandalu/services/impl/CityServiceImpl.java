package com.pr.pellisambandalu.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pr.pellisambandalu.models.Caste;
import com.pr.pellisambandalu.models.City;
import com.pr.pellisambandalu.services.CasteService;
import com.pr.pellisambandalu.services.CityService;

@Service
public class CityServiceImpl implements CityService {

	@Override
	public String addCity(String stateName, City city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<City> getCities() {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.pr.pellisambandalu.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "star")
public class Star {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "star_id")
	private long starId;
	@Column(name = "star_name")
	private String star;

}

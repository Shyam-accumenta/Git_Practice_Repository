package com.pr.pellisambandalu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.pr.pellisambandalu.models.Caste;

public interface CasteRepository extends JpaRepository<Caste, Long> {

}

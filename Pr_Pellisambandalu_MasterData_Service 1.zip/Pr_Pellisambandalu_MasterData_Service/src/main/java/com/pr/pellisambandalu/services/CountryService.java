package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.Country;

public interface CountryService {
	
	String addCountry(Country country);
	List<Country> getCountries();

}

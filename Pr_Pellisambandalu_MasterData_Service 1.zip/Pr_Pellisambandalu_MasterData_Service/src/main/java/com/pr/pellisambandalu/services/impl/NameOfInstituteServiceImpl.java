package com.pr.pellisambandalu.services.impl;

import java.util.List;

import com.pr.pellisambandalu.models.NameOfInstitute;
import com.pr.pellisambandalu.services.NameOfInstituteService;

public class NameOfInstituteServiceImpl implements NameOfInstituteService{

	@Override
	public String addNameOfInstitute(NameOfInstitute nameOfInstitute) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteNameOfInstitute(NameOfInstitute nameOfInstitute) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NameOfInstitute getNameOfInstitute(NameOfInstitute nameOfInstitute) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NameOfInstitute> getNameOfInstitutes() {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.pr.pellisambandalu.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pr.pellisambandalu.models.ZodiacSign;
import com.pr.pellisambandalu.services.ZodiacSignService;

@Service
public class ZodiacSignServiceImpl implements ZodiacSignService {

	@Override
	public String addZodiacSignService(ZodiacSign zodiacSign) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ZodiacSign> zodiacSigns() {
		// TODO Auto-generated method stub
		return null;
	}

}

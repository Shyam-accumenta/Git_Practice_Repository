package com.pr.pellisambandalu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pr.pellisambandalu.models.Star;

public interface StarRepository extends JpaRepository<Star, Long> {

}

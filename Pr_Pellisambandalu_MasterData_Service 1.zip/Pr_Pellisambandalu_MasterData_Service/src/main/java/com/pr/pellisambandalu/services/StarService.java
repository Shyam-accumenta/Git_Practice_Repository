package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.Star;

public interface StarService{
	
	String addStart(Star star);
	List<Star> getStars();

}

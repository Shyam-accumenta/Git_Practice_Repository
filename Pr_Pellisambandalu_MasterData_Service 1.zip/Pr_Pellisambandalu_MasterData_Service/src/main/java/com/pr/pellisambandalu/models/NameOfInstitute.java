package com.pr.pellisambandalu.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name="name_of_insitute")
public class NameOfInstitute {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="name_of_institute_id")
	private int nameOfInstituteId;
	@Column(name = "institute")
	private String institute;
	

}

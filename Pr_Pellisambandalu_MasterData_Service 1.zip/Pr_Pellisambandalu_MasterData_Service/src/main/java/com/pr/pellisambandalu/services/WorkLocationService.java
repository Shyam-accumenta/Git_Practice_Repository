package com.pr.pellisambandalu.services;

import java.util.List;

import com.pr.pellisambandalu.models.WorkLocation;

public interface WorkLocationService {
	
	String addWorkLocation(WorkLocation workLocation);
	List<WorkLocation> getWorkLocations();

}

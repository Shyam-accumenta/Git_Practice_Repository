package com.pr.pellisambandalu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrPellisambandaluMasterDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
